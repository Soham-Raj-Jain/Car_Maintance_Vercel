"use client"

import { useMemo } from "react"
import { useData } from "@/lib/data-store"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Car,
  DollarSign,
  Wrench,
  Bell,
  CheckCircle2,
  TrendingUp,
  CalendarClock,
} from "lucide-react"
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts"

const CHART_COLORS = [
  "hsl(213, 74%, 46%)",
  "hsl(25, 95%, 53%)",
  "hsl(152, 60%, 40%)",
  "hsl(43, 96%, 56%)",
  "hsl(0, 72%, 51%)",
  "hsl(280, 60%, 50%)",
]

function getReminderStatus(dueDate: string) {
  const now = new Date()
  const due = new Date(dueDate)
  const diff = due.getTime() - now.getTime()
  const days = Math.ceil(diff / (1000 * 60 * 60 * 24))

  if (days < 0) return "overdue"
  if (days <= 14) return "soon"
  return "ok"
}

export function Dashboard() {
  const { vehicles, services, reminders, completeReminder } = useData()

  const totalSpending = useMemo(
    () => services.reduce((sum, s) => sum + s.cost, 0),
    [services]
  )

  const avgServiceCost = useMemo(
    () => (services.length > 0 ? totalSpending / services.length : 0),
    [totalSpending, services.length]
  )

  const costByCategory = useMemo(() => {
    const map: Record<string, number> = {}
    services.forEach((s) => {
      map[s.type] = (map[s.type] || 0) + s.cost
    })
    return Object.entries(map).map(([name, value]) => ({ name, value }))
  }, [services])

  const monthlySpending = useMemo(() => {
    const map: Record<string, number> = {}
    services.forEach((s) => {
      const d = new Date(s.date)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
      map[key] = (map[key] || 0) + s.cost
    })
    return Object.entries(map)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, total]) => {
        const [y, m] = month.split("-")
        const label = new Date(Number(y), Number(m) - 1).toLocaleDateString("en-US", {
          month: "short",
          year: "2-digit",
        })
        return { month: label, total }
      })
  }, [services])

  const recentServices = useMemo(
    () =>
      [...services]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 5),
    [services]
  )

  const activeReminders = useMemo(
    () => reminders.filter((r) => !r.completed),
    [reminders]
  )

  const mostExpensiveCategory = useMemo(() => {
    if (costByCategory.length === 0) return "N/A"
    return costByCategory.reduce((max, c) => (c.value > max.value ? c : max), costByCategory[0]).name
  }, [costByCategory])

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Overview of your vehicle maintenance
        </p>
      </div>

      {/* Spending Summary Banner */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-5">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Spending</p>
                <p className="text-3xl font-bold text-foreground tracking-tight">
                  ${totalSpending.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-6">
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Services</span>
                <span className="text-lg font-semibold text-foreground">{services.length}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Avg per Service</span>
                <span className="text-lg font-semibold text-foreground">
                  ${avgServiceCost.toFixed(0)}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Top Category</span>
                <span className="text-lg font-semibold text-foreground">{mostExpensiveCategory}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Car className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Vehicles</p>
              <p className="text-2xl font-bold text-foreground">{vehicles.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <Wrench className="h-5 w-5 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Services</p>
              <p className="text-2xl font-bold text-foreground">{services.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
              <Bell className="h-5 w-5 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Reminders</p>
              <p className="text-2xl font-bold text-foreground">{activeReminders.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              Spending by Category
            </CardTitle>
          </CardHeader>
          <CardContent>
            {costByCategory.length > 0 ? (
              <div className="flex flex-col items-center gap-4">
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie
                      data={costByCategory}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={85}
                      innerRadius={45}
                      strokeWidth={2}
                      stroke="hsl(var(--card))"
                    >
                      {costByCategory.map((_, i) => (
                        <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => [`$${value.toFixed(2)}`, "Cost"]}
                      contentStyle={{
                        background: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                        color: "hsl(var(--foreground))",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-wrap justify-center gap-3">
                  {costByCategory.map((entry, i) => (
                    <div key={entry.name} className="flex items-center gap-1.5 text-xs">
                      <span
                        className="inline-block h-2.5 w-2.5 rounded-full"
                        style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }}
                      />
                      <span className="text-muted-foreground">{entry.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground py-10 text-center">No service data yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-muted-foreground" />
              Monthly Spending
            </CardTitle>
          </CardHeader>
          <CardContent>
            {monthlySpending.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={monthlySpending}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis
                    dataKey="month"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={false}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip
                    formatter={(value: number) => [`$${value.toFixed(2)}`, "Total"]}
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Bar
                    dataKey="total"
                    fill="hsl(var(--primary))"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-sm text-muted-foreground py-10 text-center">No service data yet</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Services & Reminders */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-muted-foreground" />
              Recent Services
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentServices.length > 0 ? (
              <div className="flex flex-col gap-3">
                {recentServices.map((s) => {
                  const v = vehicles.find((v) => v.id === s.vehicleId)
                  return (
                    <div
                      key={s.id}
                      className="flex items-center justify-between rounded-lg border border-border p-3"
                    >
                      <div className="flex flex-col gap-0.5">
                        <p className="text-sm font-medium text-foreground">{s.type}</p>
                        <p className="text-xs text-muted-foreground">
                          {v ? `${v.year} ${v.make} ${v.model}` : "Unknown Vehicle"} &middot;{" "}
                          {new Date(s.date).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                      <span className="text-sm font-semibold text-foreground">
                        ${s.cost.toFixed(2)}
                      </span>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground py-6 text-center">No services recorded yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Bell className="h-4 w-4 text-muted-foreground" />
              Upcoming Reminders
            </CardTitle>
          </CardHeader>
          <CardContent>
            {activeReminders.length > 0 ? (
              <div className="flex flex-col gap-3">
                {activeReminders.map((r) => {
                  const status = getReminderStatus(r.dueDate)
                  const v = vehicles.find((v) => v.id === r.vehicleId)
                  return (
                    <div
                      key={r.id}
                      className="flex items-center justify-between rounded-lg border border-border p-3"
                    >
                      <div className="flex flex-col gap-0.5">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-foreground">{r.serviceType}</p>
                          <Badge
                            variant={
                              status === "overdue"
                                ? "destructive"
                                : status === "soon"
                                  ? "secondary"
                                  : "default"
                            }
                            className={
                              status === "soon"
                                ? "bg-[hsl(var(--warning))] text-[hsl(var(--warning-foreground))]"
                                : status === "ok"
                                  ? "bg-[hsl(var(--success))] text-[hsl(var(--success-foreground))]"
                                  : ""
                            }
                          >
                            {status === "overdue"
                              ? "Overdue"
                              : status === "soon"
                                ? "Due Soon"
                                : "On Track"}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {v ? `${v.year} ${v.make} ${v.model}` : "Unknown"} &middot;{" "}
                          {new Date(r.dueDate).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </p>
                        <p className="text-xs text-muted-foreground">{r.description}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[hsl(var(--success))] hover:text-[hsl(var(--success))] hover:bg-[hsl(var(--success))]/10 gap-1.5 shrink-0"
                        onClick={() => completeReminder(r.id)}
                      >
                        <CheckCircle2 className="h-4 w-4" />
                        <span className="hidden sm:inline">Complete</span>
                      </Button>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground py-6 text-center">All reminders completed</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
