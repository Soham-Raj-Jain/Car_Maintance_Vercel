"use client"

import { useState, useMemo } from "react"
import { useData } from "@/lib/data-store"
import { SERVICE_TYPES, type ServiceType } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Plus, Search, Trash2, Wrench } from "lucide-react"

const emptyService = {
  vehicleId: "",
  type: "" as ServiceType,
  date: "",
  mileage: 0,
  cost: 0,
  shop: "",
  notes: "",
}

export function ServicesPage() {
  const { vehicles, services, addService, deleteService } = useData()
  const [addOpen, setAddOpen] = useState(false)
  const [form, setForm] = useState(emptyService)
  const [filterVehicle, setFilterVehicle] = useState("all")
  const [search, setSearch] = useState("")

  const filtered = useMemo(() => {
    return [...services]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .filter((s) => {
        if (filterVehicle !== "all" && s.vehicleId !== filterVehicle) return false
        if (search) {
          const q = search.toLowerCase()
          const v = vehicles.find((v) => v.id === s.vehicleId)
          const vehicleName = v ? `${v.year} ${v.make} ${v.model}`.toLowerCase() : ""
          return (
            s.type.toLowerCase().includes(q) ||
            s.shop.toLowerCase().includes(q) ||
            s.notes.toLowerCase().includes(q) ||
            vehicleName.includes(q)
          )
        }
        return true
      })
  }, [services, filterVehicle, search, vehicles])

  function handleAdd() {
    if (!form.vehicleId || !form.type || !form.date) return
    addService(form)
    setForm(emptyService)
    setAddOpen(false)
  }

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Service History</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {services.length} service record{services.length !== 1 ? "s" : ""}
          </p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 self-start sm:self-auto">
              <Plus className="h-4 w-4" /> Add Service
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Add Service Record</DialogTitle>
            </DialogHeader>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2">
                <Label>Vehicle</Label>
                <Select
                  value={form.vehicleId}
                  onValueChange={(v) => setForm({ ...form, vehicleId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select vehicle" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles.map((v) => (
                      <SelectItem key={v.id} value={v.id}>
                        {v.year} {v.make} {v.model}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-2">
                  <Label>Service Type</Label>
                  <Select
                    value={form.type}
                    onValueChange={(v) => setForm({ ...form, type: v as ServiceType })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {SERVICE_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="svc-date">Date</Label>
                  <Input
                    id="svc-date"
                    type="date"
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="svc-mileage">Mileage</Label>
                  <Input
                    id="svc-mileage"
                    type="number"
                    value={form.mileage || ""}
                    onChange={(e) => setForm({ ...form, mileage: Number(e.target.value) })}
                    placeholder="34000"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="svc-cost">Cost ($)</Label>
                  <Input
                    id="svc-cost"
                    type="number"
                    step="0.01"
                    value={form.cost || ""}
                    onChange={(e) => setForm({ ...form, cost: Number(e.target.value) })}
                    placeholder="75.00"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="svc-shop">Shop Name</Label>
                <Input
                  id="svc-shop"
                  value={form.shop}
                  onChange={(e) => setForm({ ...form, shop: e.target.value })}
                  placeholder="QuickLube Express"
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="svc-notes">Notes</Label>
                <Textarea
                  id="svc-notes"
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Additional details..."
                  rows={3}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">
                Save Record
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search services..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={filterVehicle} onValueChange={setFilterVehicle}>
          <SelectTrigger className="w-full sm:w-52">
            <SelectValue placeholder="All vehicles" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Vehicles</SelectItem>
            {vehicles.map((v) => (
              <SelectItem key={v.id} value={v.id}>
                {v.year} {v.make} {v.model}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {filtered.length > 0 ? (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Cost</TableHead>
                    <TableHead>Shop</TableHead>
                    <TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((s) => {
                    const v = vehicles.find((v) => v.id === s.vehicleId)
                    return (
                      <TableRow key={s.id}>
                        <TableCell className="text-sm">
                          {new Date(s.date).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </TableCell>
                        <TableCell className="text-sm font-medium">
                          {v ? `${v.year} ${v.make} ${v.model}` : "Unknown"}
                        </TableCell>
                        <TableCell className="text-sm">{s.type}</TableCell>
                        <TableCell className="text-sm text-right font-semibold">
                          ${s.cost.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {s.shop}
                        </TableCell>
                        <TableCell>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                                <Trash2 className="h-3.5 w-3.5" />
                                <span className="sr-only">Delete service</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Service Record</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete this service record. This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteService(s.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-12 flex flex-col items-center gap-4">
            <Wrench className="h-12 w-12 text-muted-foreground/30" />
            <div className="text-center">
              <p className="text-sm font-medium text-foreground">
                {services.length === 0 ? "No service records yet" : "No matching records"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {services.length === 0
                  ? "Add your first service record to start tracking"
                  : "Try adjusting your search or filter"}
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
