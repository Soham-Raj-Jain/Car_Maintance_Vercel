"use client"

import { useState } from "react"
import { useData } from "@/lib/data-store"
import type { Vehicle } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Plus, Pencil, Trash2, Car, Fuel } from "lucide-react"

function FuelGauge({ mileage }: { mileage: number }) {
  // Normalize mileage to a percentage (0-200k range)
  const maxMileage = 200000
  const percentage = Math.min((mileage / maxMileage) * 100, 100)
  const fillColor =
    percentage < 33
      ? "hsl(var(--success))"
      : percentage < 66
        ? "hsl(var(--warning))"
        : "hsl(var(--destructive))"

  return (
    <div className="flex items-center gap-2">
      <Fuel className="h-4 w-4 text-muted-foreground shrink-0" />
      <div className="flex flex-col gap-1 flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">Mileage</span>
          <span className="text-xs font-semibold text-foreground">
            {mileage.toLocaleString()} mi
          </span>
        </div>
        <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${percentage}%`, backgroundColor: fillColor }}
          />
        </div>
      </div>
    </div>
  )
}

const emptyVehicle = { make: "", model: "", year: new Date().getFullYear(), mileage: 0, imageUrl: "" }

export function VehiclesPage() {
  const { vehicles, addVehicle, updateVehicle, deleteVehicle, services } = useData()
  const [addOpen, setAddOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [form, setForm] = useState(emptyVehicle)
  const [editId, setEditId] = useState<string | null>(null)

  function handleAdd() {
    if (!form.make || !form.model) return
    addVehicle(form)
    setForm(emptyVehicle)
    setAddOpen(false)
  }

  function startEdit(v: Vehicle) {
    setEditId(v.id)
    setForm({ make: v.make, model: v.model, year: v.year, mileage: v.mileage, imageUrl: v.imageUrl })
    setEditOpen(true)
  }

  function handleEdit() {
    if (!editId || !form.make || !form.model) return
    updateVehicle(editId, form)
    setEditId(null)
    setForm(emptyVehicle)
    setEditOpen(false)
  }

  function getVehicleSpending(vehicleId: string) {
    return services.filter((s) => s.vehicleId === vehicleId).reduce((sum, s) => sum + s.cost, 0)
  }

  function getVehicleServiceCount(vehicleId: string) {
    return services.filter((s) => s.vehicleId === vehicleId).length
  }

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Vehicles</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your fleet of {vehicles.length} vehicle{vehicles.length !== 1 ? "s" : ""}
          </p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" /> Add Vehicle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Vehicle</DialogTitle>
            </DialogHeader>
            <VehicleForm form={form} setForm={setForm} onSubmit={handleAdd} label="Add" />
          </DialogContent>
        </Dialog>
      </div>

      {vehicles.length > 0 ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {vehicles.map((v) => (
            <Card key={v.id} className="overflow-hidden group">
              <div className="aspect-[16/9] bg-muted flex items-center justify-center relative">
                {v.imageUrl ? (
                  <img
                    src={v.imageUrl}
                    alt={`${v.year} ${v.make} ${v.model}`}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <Car className="h-16 w-16 text-muted-foreground/30" />
                )}
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="secondary"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => startEdit(v)}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    <span className="sr-only">Edit {v.make} {v.model}</span>
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="icon" className="h-8 w-8">
                        <Trash2 className="h-3.5 w-3.5" />
                        <span className="sr-only">Delete {v.make} {v.model}</span>
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Vehicle</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently delete the {v.year} {v.make} {v.model} and all its
                          service records. This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => deleteVehicle(v.id)}>
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
              <CardContent className="p-4 flex flex-col gap-3">
                <div>
                  <h3 className="text-base font-semibold text-foreground">
                    {v.year} {v.make} {v.model}
                  </h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-muted-foreground">
                      {getVehicleServiceCount(v.id)} services
                    </span>
                    <span className="text-xs text-muted-foreground">
                      ${getVehicleSpending(v.id).toLocaleString()} spent
                    </span>
                  </div>
                </div>
                <FuelGauge mileage={v.mileage} />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 flex flex-col items-center gap-4">
            <Car className="h-12 w-12 text-muted-foreground/30" />
            <div className="text-center">
              <p className="text-sm font-medium text-foreground">No vehicles added yet</p>
              <p className="text-xs text-muted-foreground mt-1">
                Add your first vehicle to start tracking maintenance
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Vehicle</DialogTitle>
          </DialogHeader>
          <VehicleForm form={form} setForm={setForm} onSubmit={handleEdit} label="Save" />
        </DialogContent>
      </Dialog>
    </div>
  )
}

function VehicleForm({
  form,
  setForm,
  onSubmit,
  label,
}: {
  form: Omit<Vehicle, "id">
  setForm: (f: Omit<Vehicle, "id">) => void
  onSubmit: () => void
  label: string
}) {
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="make">Make</Label>
          <Input
            id="make"
            value={form.make}
            onChange={(e) => setForm({ ...form, make: e.target.value })}
            placeholder="Toyota"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="model">Model</Label>
          <Input
            id="model"
            value={form.model}
            onChange={(e) => setForm({ ...form, model: e.target.value })}
            placeholder="Camry"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="year">Year</Label>
          <Input
            id="year"
            type="number"
            value={form.year}
            onChange={(e) => setForm({ ...form, year: Number(e.target.value) })}
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="mileage">Mileage</Label>
          <Input
            id="mileage"
            type="number"
            value={form.mileage}
            onChange={(e) => setForm({ ...form, mileage: Number(e.target.value) })}
          />
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <Label htmlFor="imageUrl">Image URL (optional)</Label>
        <Input
          id="imageUrl"
          value={form.imageUrl}
          onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
          placeholder="https://example.com/image.jpg"
        />
      </div>
      <Button onClick={onSubmit} className="w-full">
        {label}
      </Button>
    </div>
  )
}
