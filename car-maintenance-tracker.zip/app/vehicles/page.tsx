"use client"

import { useState } from "react"
import { useData } from "@/lib/data-store"
import type { Vehicle } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Car, Plus, Pencil, Trash2, Fuel, Gauge } from "lucide-react"

function FuelGaugeIcon({ mileage }: { mileage: number }) {
  // Normalize mileage: 0-200k maps to a gauge visual
  const maxMileage = 200000
  const percentage = Math.min((mileage / maxMileage) * 100, 100)
  const gaugeColor =
    percentage > 75
      ? "text-destructive"
      : percentage > 50
        ? "text-[hsl(var(--warning))]"
        : percentage > 25
          ? "text-accent"
          : "text-[hsl(var(--success))]"

  return (
    <div className="flex items-center gap-2">
      <Fuel className={`h-4 w-4 ${gaugeColor}`} />
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-1.5">
          <div className="h-1.5 w-20 rounded-full bg-muted overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                percentage > 75
                  ? "bg-destructive"
                  : percentage > 50
                    ? "bg-[hsl(var(--warning))]"
                    : percentage > 25
                      ? "bg-accent"
                      : "bg-[hsl(var(--success))]"
              }`}
              style={{ width: `${percentage}%` }}
            />
          </div>
          <span className="text-xs font-medium text-muted-foreground">
            {mileage.toLocaleString()} mi
          </span>
        </div>
      </div>
    </div>
  )
}

type VehicleFormData = Omit<Vehicle, "id">

const emptyForm: VehicleFormData = {
  make: "",
  model: "",
  year: new Date().getFullYear(),
  mileage: 0,
  imageUrl: "",
}

export default function VehiclesPage() {
  const { vehicles, addVehicle, updateVehicle, deleteVehicle, services } = useData()
  const [addOpen, setAddOpen] = useState(false)
  const [editVehicle, setEditVehicle] = useState<Vehicle | null>(null)
  const [form, setForm] = useState<VehicleFormData>(emptyForm)

  function handleAddOpen() {
    setForm(emptyForm)
    setAddOpen(true)
  }

  function handleEditOpen(vehicle: Vehicle) {
    setForm({
      make: vehicle.make,
      model: vehicle.model,
      year: vehicle.year,
      mileage: vehicle.mileage,
      imageUrl: vehicle.imageUrl,
    })
    setEditVehicle(vehicle)
  }

  function handleSaveAdd() {
    if (!form.make || !form.model) return
    addVehicle(form)
    setAddOpen(false)
    setForm(emptyForm)
  }

  function handleSaveEdit() {
    if (!editVehicle || !form.make || !form.model) return
    updateVehicle(editVehicle.id, form)
    setEditVehicle(null)
    setForm(emptyForm)
  }

  function getVehicleServiceCount(vehicleId: string) {
    return services.filter((s) => s.vehicleId === vehicleId).length
  }

  function getVehicleTotalCost(vehicleId: string) {
    return services
      .filter((s) => s.vehicleId === vehicleId)
      .reduce((sum, s) => sum + s.cost, 0)
  }

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground tracking-tight">Vehicles</h2>
          <p className="text-sm text-muted-foreground">Manage your registered vehicles</p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddOpen} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Vehicle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Vehicle</DialogTitle>
              <DialogDescription>Enter the details for your new vehicle.</DialogDescription>
            </DialogHeader>
            <VehicleForm form={form} setForm={setForm} />
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline">Cancel</Button>
              </DialogClose>
              <Button onClick={handleSaveAdd} disabled={!form.make || !form.model}>
                Add Vehicle
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {vehicles.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
              <Car className="h-7 w-7 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">No vehicles yet. Add your first one!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {vehicles.map((vehicle) => (
            <Card key={vehicle.id} className="overflow-hidden">
              <div className="flex h-36 items-center justify-center bg-muted/50">
                <Car className="h-16 w-16 text-muted-foreground/40" />
              </div>
              <CardContent className="p-4 flex flex-col gap-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-base font-semibold text-foreground">
                      {vehicle.year} {vehicle.make} {vehicle.model}
                    </h3>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      <span>{getVehicleServiceCount(vehicle.id)} services</span>
                      <span>&middot;</span>
                      <span>
                        ${getVehicleTotalCost(vehicle.id).toLocaleString()} spent
                      </span>
                    </div>
                  </div>
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <Gauge className="h-4 w-4 text-primary" />
                  </div>
                </div>

                {/* Fuel gauge mileage display */}
                <FuelGaugeIcon mileage={vehicle.mileage} />

                <div className="flex items-center gap-2 pt-1">
                  <Dialog
                    open={editVehicle?.id === vehicle.id}
                    onOpenChange={(open) => {
                      if (!open) setEditVehicle(null)
                    }}
                  >
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 gap-1.5"
                        onClick={() => handleEditOpen(vehicle)}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit Vehicle</DialogTitle>
                        <DialogDescription>Update the vehicle details.</DialogDescription>
                      </DialogHeader>
                      <VehicleForm form={form} setForm={setForm} />
                      <DialogFooter>
                        <DialogClose asChild>
                          <Button variant="outline">Cancel</Button>
                        </DialogClose>
                        <Button onClick={handleSaveEdit} disabled={!form.make || !form.model}>
                          Save Changes
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive">
                        <Trash2 className="h-3.5 w-3.5" />
                        Delete
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Vehicle?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently delete the {vehicle.year} {vehicle.make} {vehicle.model} and all
                          associated service records and reminders.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deleteVehicle(vehicle.id)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function VehicleForm({
  form,
  setForm,
}: {
  form: VehicleFormData
  setForm: React.Dispatch<React.SetStateAction<VehicleFormData>>
}) {
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="make">Make</Label>
          <Input
            id="make"
            placeholder="Toyota"
            value={form.make}
            onChange={(e) => setForm((f) => ({ ...f, make: e.target.value }))}
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="model">Model</Label>
          <Input
            id="model"
            placeholder="Camry"
            value={form.model}
            onChange={(e) => setForm((f) => ({ ...f, model: e.target.value }))}
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="year">Year</Label>
          <Input
            id="year"
            type="number"
            value={form.year}
            onChange={(e) => setForm((f) => ({ ...f, year: parseInt(e.target.value) || 0 }))}
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="mileage">Mileage</Label>
          <Input
            id="mileage"
            type="number"
            value={form.mileage}
            onChange={(e) => setForm((f) => ({ ...f, mileage: parseInt(e.target.value) || 0 }))}
          />
        </div>
      </div>
    </div>
  )
}
