"use client"

import { useData } from "@/lib/data-store"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Car,
  Wrench,
  DollarSign,
  Bell,
  CheckCircle2,
  Clock,
  AlertTriangle,
  TrendingUp,
} from "lucide-react"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts"

const CHART_COLORS = [
  "hsl(213, 74%, 46%)",
  "hsl(25, 95%, 53%)",
  "hsl(152, 60%, 40%)",
  "hsl(43, 96%, 56%)",
  "hsl(0, 72%, 51%)",
  "hsl(280, 60%, 50%)",
]

function getReminderStatus(dueDate: string) {
  const now = new Date()
  const due = new Date(dueDate)
  const diffDays = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
  if (diffDays < 0) return "overdue"
  if (diffDays <= 14) return "soon"
  return "ok"
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

export default function DashboardPage() {
  const { vehicles, services, reminders, completeReminder } = useData()

  const totalSpending = services.reduce((sum, s) => sum + s.cost, 0)
  const avgPerService = services.length > 0 ? totalSpending / services.length : 0
  const thisYearServices = services.filter((s) => new Date(s.date).getFullYear() === new Date().getFullYear())
  const thisYearSpending = thisYearServices.reduce((sum, s) => sum + s.cost, 0)

  const recentServices = [...services]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)

  const costByCategory = services.reduce<Record<string, number>>((acc, s) => {
    acc[s.type] = (acc[s.type] || 0) + s.cost
    return acc
  }, {})

  const pieData = Object.entries(costByCategory).map(([name, value]) => ({ name, value }))

  const activeReminders = reminders.filter((r) => !r.completed)

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground tracking-tight">Dashboard</h2>
        <p className="text-sm text-muted-foreground">Overview of your vehicle maintenance</p>
      </div>

      {/* Total Spending Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-primary/10">
              <DollarSign className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
              <p className="text-xl font-bold text-foreground">{formatCurrency(totalSpending)}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-accent/10">
              <TrendingUp className="h-5 w-5 text-accent" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">This Year</p>
              <p className="text-xl font-bold text-foreground">{formatCurrency(thisYearSpending)}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-primary/10">
              <Car className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Vehicles</p>
              <p className="text-xl font-bold text-foreground">{vehicles.length}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-accent/10">
              <Wrench className="h-5 w-5 text-accent" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Avg. Per Service</p>
              <p className="text-xl font-bold text-foreground">{formatCurrency(avgPerService)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Maintenance */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Maintenance</CardTitle>
            <CardDescription>Last 5 service records</CardDescription>
          </CardHeader>
          <CardContent>
            {recentServices.length === 0 ? (
              <p className="text-sm text-muted-foreground">No service records yet.</p>
            ) : (
              <div className="flex flex-col gap-3">
                {recentServices.map((service) => {
                  const vehicle = vehicles.find((v) => v.id === service.vehicleId)
                  return (
                    <div
                      key={service.id}
                      className="flex items-center justify-between rounded-lg border border-border p-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-muted">
                          <Wrench className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{service.type}</p>
                          <p className="text-xs text-muted-foreground">
                            {vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : "Unknown"} &middot;{" "}
                            {formatDate(service.date)}
                          </p>
                        </div>
                      </div>
                      <span className="text-sm font-semibold text-foreground">{formatCurrency(service.cost)}</span>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Spending by Category Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Spending by Category</CardTitle>
            <CardDescription>Cost breakdown across service types</CardDescription>
          </CardHeader>
          <CardContent>
            {pieData.length === 0 ? (
              <p className="text-sm text-muted-foreground">No data yet.</p>
            ) : (
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {pieData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "var(--radius)",
                        color: "hsl(var(--card-foreground))",
                      }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Reminders with Mark as Complete */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base">Upcoming Reminders</CardTitle>
              <CardDescription>Scheduled maintenance and inspections</CardDescription>
            </div>
            <Bell className="h-5 w-5 text-muted-foreground" />
          </div>
        </CardHeader>
        <CardContent>
          {activeReminders.length === 0 ? (
            <p className="text-sm text-muted-foreground">No upcoming reminders. All caught up!</p>
          ) : (
            <div className="flex flex-col gap-3">
              {activeReminders.map((reminder) => {
                const vehicle = vehicles.find((v) => v.id === reminder.vehicleId)
                const status = getReminderStatus(reminder.dueDate)
                return (
                  <div
                    key={reminder.id}
                    className="flex items-center justify-between rounded-lg border border-border p-3"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-md ${
                          status === "overdue"
                            ? "bg-destructive/10"
                            : status === "soon"
                              ? "bg-[hsl(var(--warning))]/10"
                              : "bg-[hsl(var(--success))]/10"
                        }`}
                      >
                        {status === "overdue" ? (
                          <AlertTriangle className="h-4 w-4 text-destructive" />
                        ) : status === "soon" ? (
                          <Clock className="h-4 w-4 text-[hsl(var(--warning))]" />
                        ) : (
                          <CheckCircle2 className="h-4 w-4 text-[hsl(var(--success))]" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-foreground">{reminder.serviceType}</p>
                          <Badge
                            variant={status === "overdue" ? "destructive" : "secondary"}
                            className={
                              status === "soon"
                                ? "bg-[hsl(var(--warning))]/15 text-[hsl(var(--warning))] border-[hsl(var(--warning))]/30"
                                : status === "ok"
                                  ? "bg-[hsl(var(--success))]/15 text-[hsl(var(--success))] border-[hsl(var(--success))]/30"
                                  : ""
                            }
                          >
                            {status === "overdue" ? "Overdue" : status === "soon" ? "Due Soon" : "On Track"}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : "Unknown"} &middot;{" "}
                          {reminder.description} &middot; Due {formatDate(reminder.dueDate)}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="shrink-0 gap-1.5"
                      onClick={() => completeReminder(reminder.id)}
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Mark Complete</span>
                    </Button>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
