"use client"

import React, { createContext, useContext, useState, useEffect, useCallback } from "react"
import type { Vehicle, ServiceRecord, Reminder } from "./types"

interface DataStore {
  vehicles: Vehicle[]
  services: ServiceRecord[]
  reminders: Reminder[]
  addVehicle: (vehicle: Omit<Vehicle, "id">) => void
  updateVehicle: (id: string, vehicle: Partial<Vehicle>) => void
  deleteVehicle: (id: string) => void
  addService: (service: Omit<ServiceRecord, "id">) => void
  deleteService: (id: string) => void
  addReminder: (reminder: Omit<Reminder, "id">) => void
  deleteReminder: (id: string) => void
  completeReminder: (id: string) => void
}

const DataContext = createContext<DataStore | null>(null)

function generateId() {
  return Math.random().toString(36).substring(2, 9) + Date.now().toString(36)
}

const SAMPLE_VEHICLES: Vehicle[] = [
  {
    id: "v1",
    make: "Toyota",
    model: "Camry",
    year: 2021,
    mileage: 34500,
    imageUrl: "",
  },
  {
    id: "v2",
    make: "Honda",
    model: "CR-V",
    year: 2023,
    mileage: 12800,
    imageUrl: "",
  },
]

const SAMPLE_SERVICES: ServiceRecord[] = [
  {
    id: "s1",
    vehicleId: "v1",
    type: "Oil Change",
    date: "2026-01-15",
    mileage: 34000,
    cost: 75,
    shop: "QuickLube Express",
    notes: "Synthetic blend, filter replaced",
  },
  {
    id: "s2",
    vehicleId: "v1",
    type: "Tire Rotation",
    date: "2025-11-20",
    mileage: 32000,
    cost: 45,
    shop: "Discount Tire",
    notes: "All tires in good condition",
  },
  {
    id: "s3",
    vehicleId: "v2",
    type: "Inspection",
    date: "2026-02-01",
    mileage: 12500,
    cost: 35,
    shop: "Honda Dealership",
    notes: "Passed state inspection",
  },
  {
    id: "s4",
    vehicleId: "v1",
    type: "Brake Service",
    date: "2025-09-10",
    mileage: 30000,
    cost: 320,
    shop: "Meineke Auto",
    notes: "Front brake pads and rotors replaced",
  },
  {
    id: "s5",
    vehicleId: "v2",
    type: "Battery",
    date: "2025-12-05",
    mileage: 12000,
    cost: 180,
    shop: "AutoZone",
    notes: "New AGM battery installed",
  },
]

const SAMPLE_REMINDERS: Reminder[] = [
  {
    id: "r1",
    vehicleId: "v1",
    serviceType: "Oil Change",
    dueDate: "2026-04-15",
    description: "Next oil change due at 37,000 miles",
  },
  {
    id: "r2",
    vehicleId: "v2",
    serviceType: "Tire Rotation",
    dueDate: "2026-02-10",
    description: "Tire rotation overdue",
  },
  {
    id: "r3",
    vehicleId: "v1",
    serviceType: "Inspection",
    dueDate: "2026-03-01",
    description: "Annual state inspection",
  },
]

function loadFromStorage<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback
  try {
    const item = localStorage.getItem(key)
    return item ? JSON.parse(item) : fallback
  } catch {
    return fallback
  }
}

function saveToStorage<T>(key: string, value: T) {
  if (typeof window === "undefined") return
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    // storage full or unavailable
  }
}

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [services, setServices] = useState<ServiceRecord[]>([])
  const [reminders, setReminders] = useState<Reminder[]>([])
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    setVehicles(loadFromStorage("car-tracker-vehicles", SAMPLE_VEHICLES))
    setServices(loadFromStorage("car-tracker-services", SAMPLE_SERVICES))
    setReminders(loadFromStorage("car-tracker-reminders", SAMPLE_REMINDERS))
    setLoaded(true)
  }, [])

  useEffect(() => {
    if (loaded) saveToStorage("car-tracker-vehicles", vehicles)
  }, [vehicles, loaded])

  useEffect(() => {
    if (loaded) saveToStorage("car-tracker-services", services)
  }, [services, loaded])

  useEffect(() => {
    if (loaded) saveToStorage("car-tracker-reminders", reminders)
  }, [reminders, loaded])

  const addVehicle = useCallback((vehicle: Omit<Vehicle, "id">) => {
    setVehicles((prev) => [...prev, { ...vehicle, id: generateId() }])
  }, [])

  const updateVehicle = useCallback((id: string, updates: Partial<Vehicle>) => {
    setVehicles((prev) =>
      prev.map((v) => (v.id === id ? { ...v, ...updates } : v))
    )
  }, [])

  const deleteVehicle = useCallback((id: string) => {
    setVehicles((prev) => prev.filter((v) => v.id !== id))
    setServices((prev) => prev.filter((s) => s.vehicleId !== id))
    setReminders((prev) => prev.filter((r) => r.vehicleId !== id))
  }, [])

  const addService = useCallback((service: Omit<ServiceRecord, "id">) => {
    setServices((prev) => [...prev, { ...service, id: generateId() }])
  }, [])

  const deleteService = useCallback((id: string) => {
    setServices((prev) => prev.filter((s) => s.id !== id))
  }, [])

  const addReminder = useCallback((reminder: Omit<Reminder, "id">) => {
    setReminders((prev) => [...prev, { ...reminder, id: generateId() }])
  }, [])

  const deleteReminder = useCallback((id: string) => {
    setReminders((prev) => prev.filter((r) => r.id !== id))
  }, [])

  const completeReminder = useCallback((id: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, completed: true } : r))
    )
  }, [])

  if (!loaded) {
    return null
  }

  return (
    <DataContext.Provider
      value={{
        vehicles,
        services,
        reminders,
        addVehicle,
        updateVehicle,
        deleteVehicle,
        addService,
        deleteService,
        addReminder,
        deleteReminder,
        completeReminder,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (!context) {
    throw new Error("useData must be used within a DataProvider")
  }
  return context
}
